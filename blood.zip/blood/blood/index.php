<?php 
include 'include/connect.php'; 

include 'include/header.php'; 

?>
 
<form role="form" action="<?php echo htmlspecialchars('index.php'); ?>" method="post">
<div class="intro">
<div class="dtable hw100">
<div class="dtable-cell hw100">
<div class="container text-center">
<h1 class="intro-title animated fadeInDown"> Find Blood Donor </h1>
<p class="sub animateme fittext3 animated fadeIn"> Find available blood donors in Minutes </p>
<div class="row search-row animated fadeInUp">
<div class="col-lg-4 col-sm-4 search-col relative"> <i class="icon-water icon-append"></i>
<select class="form-control has-icon" name="blood" id="id-location" tabindex="-1">
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
</select>
</div>
<div class="col-lg-4 col-sm-4 search-col relative locationicon">
<i class="icon-location-2 icon-append"></i>
<select class="form-control has-icon" name="state" id="id-location" tabindex="-1">
<option value="Abia">Abia</option>
<option value="Adamawa">Adamawa</option>
<option value="Abuja">Abuja</option>
<option value="Akwa ibom">Akwa ibom</option>
<option value="Anambra">Anambra</option>
<option value="Bauchi">Bauchi</option>
<option value="Bayelsa">Bayelsa</option>
<option value="Benue">Benue</option>
<option value="Borno">Borno</option>
<option value="Cross river">Cross river</option>
<option value="Delta">Delta</option>
<option value="Ebonyi">Ebonyi</option>
<option value="Edo">Edo</option>
<option value="Ekiti">Ekiti</option>
<option value="Enugu">Enugu</option>
<option value="Gombe">Gombe</option>
<option value="Imo">Imo</option>
<option value="Jigawa">Jigawa</option>
<option value="Kaduna">Kaduna</option>
<option value="Kano">Kano</option>
<option value="Katsina">Katsina</option>
<option value="Kebbi">Kebbi</option>
<option value="Kogi">Kogi</option>
<option value="Kwara">Kwara</option>
<option value="Nassarawa">Nassarawa</option>
<option value="Niger">Niger</option>
<option value="Lagos">Lagos</option>
<option value="Ogun">Ogun</option>
<option value="Ondo">Ondo</option>
<option value="Osun">Osun</option>
<option value="Oyo">Oyo</option>
<option value="Plateau">Plateau</option>
<option value="Rivers">Rivers</option>
<option value="Sokoto">Sokoto</option>
<option value="Taraba">Taraba</option>
<option value="Yobe">Yobe</option>
<option value="Zamfara">Zamfara</option>
</select>
</div>
<div class="col-lg-4 col-sm-4 search-col">
<button type="submit" name="search" class="btn btn-primary btn-search btn-block"><i class="icon-search"></i><strong>Find</strong></button>
</div>
</div>
</div>
</div>
</div>
</div>
</form>
 
<div class="main-container">

<div class="container">
<?php
if (isset($_POST['donate'])) {
	$username = $_SESSION['username'];

	$q = $query->prepare("SELECT * FROM donors WHERE username = :username");
	$q->bindParam(':username', $username);
	$q->execute();

	if ($q->rowCount() != 0) {
		$update = $query->prepare("UPDATE donors SET status = 0 WHERE username = :username");
		$update->bindParam('username', $username);

		if ($update->execute()) {
			?>
<div class="alert alert-success">
<strong>Your name and contact info have been added to the blood bank donor directory.</strong><br>
Thank you for saving a life.<br>
Reloading page...
</div>
<script>
setTimeout(function() {
window.location.replace('index.php');
}, 2000);
</script>
			<?php
		}else{
?>
<div class="alert alert-danger">
<strong>Unable to add name in blood donor directory.</strong>
</div>
<?php
		}


	}else{
		$username = $_SESSION['username'];

		$q2 = $query->prepare("SELECT * FROM account WHERE username = :username");
	$q2->bindParam(':username', $username);
	$q2->execute();

	$info = $q2->fetch();
	$state = $info['state'];
	$blood = $info['blood'];

		$insert = $query->prepare("INSERT INTO donors (username, date, time, blood, state) VALUES (:username, :d, :t, :blood, :state)");
		$insert->bindParam(':username', $username);
		$insert->bindParam(':d', $d);
		$insert->bindParam(':t', $t);
		$insert->bindParam(':state', $state);		
		$insert->bindParam(':blood', $blood);

		if ($insert->execute()) {
			?>
<div class="alert alert-success">
<strong>Your name and contact info have been added to the blood bank donor directory.</strong><br>
Thank you for saving a life.<br>
Reloading page...
</div>
<script>
setTimeout(function() {
window.location.replace('index.php');
}, 2000);
</script>
			<?php
		}else{
?>
<div class="alert alert-danger">
<strong>Unable to add name in blood donor directory.</strong>
</div>
<?php
		}

	}
}

if (isset($_POST['cancel'])) {
	$username = $_SESSION['username'];

		$update = $query->prepare("UPDATE donors SET status = 1 WHERE username = :username");
		$update->bindParam('username', $username);

		if ($update->execute()) {
			?>
<div class="alert alert-success">
<strong>Your name and contact info have been removed from the blood bank donor directory.</strong><br>
Reloading page...
</div>
<script>
setTimeout(function() {
window.location.replace('index.php');
}, 2000);
</script>
			<?php
		}else{
?>
<div class="alert alert-danger">
<strong>Unable to remove name in blood donor directory.</strong>
</div>
<?php
		}
}
?>
<div class="row" style="margin: 0 -5px;">
<div class="inner-box category-content">
<h2 class="title-2">
<?php
if (isset($_POST['search'])) {
$state = secureText($_POST['state']);
	$blood = secureText($_POST['blood']);
	?>
Finding blood donors in <?php echo $state; ?> state with blood group <?php echo $blood; ?>
	<?php
}else{
	echo "Available donors";
}
?> </h2>
<div class="row">

<?php

if (isset($_POST['search'])) {
	$state = secureText($_POST['state']);
	$blood = secureText($_POST['blood']);

	$q = $query->prepare("SELECT * FROM donors WHERE blood = :blood AND status = 0 AND state = :state ORDER BY id DESC");
	$q->bindParam(':blood', $blood);
	$q->bindParam(':state', $state);
	$q->execute();

	if ($q->rowCount() != 0) {
		?>
<table class="table">
      <thead>
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>State</th>
          <th>City</th>
          <th>Phone Number</th>
          <th>Email Address</th>
        </tr>
      </thead>
      <tbody>
      <?php
while ($row = $q->fetch()) {
	$username = $row['username'];
	$q2 = $query->prepare("SELECT * FROM account WHERE username = :username");
	$q2->bindParam(':username', $username);
	$q2->execute();

	$info = $q2->fetch();
	?>
<tr>
          <td><?php echo $info['first_name']; ?></td>
          <td><?php echo $info['last_name']; ?></td>
          <td><?php echo $info['state']; ?></td>
          <td><?php echo $info['city']; ?></td>
          <td>
          	<?php
if (isset($_SESSION['username'])) {
	echo "{$info['phone']}";
}else{
	?>
<a href="login.php" class="btn btn-info">Login to see contact</a>
	<?php
}
          	?>
          </td>
          <td><?php
if (isset($_SESSION['username'])) {
	echo "{$info['email']}";
}else{
	?>
<a href="login.php" class="btn btn-info">Login to see contact</a>
	<?php
}
          	?></td>
        </tr>
	<?php
}
      ?>
        
      </tbody>
    </table>
		<?php
	}else{
		?>
<div class="alert alert-danger">
No donor in <?php echo $state; ?> with blood group <?php echo $blood; ?>
</div>
		<?php
	}
}else{
	$q = $query->prepare("SELECT * FROM donors WHERE status = 0 ORDER BY id DESC");
$q->execute();

if ($q->rowCount() != 0) {
	?>
<table class="table">
      <thead>
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>State</th>
          <th>City</th>
          <th>Phone Number</th>
          <th>Email Address</th>
        </tr>
      </thead>
      <tbody>
      <?php
while ($row = $q->fetch()) {
	$username = $row['username'];
	$q2 = $query->prepare("SELECT * FROM account WHERE username = :username");
	$q2->bindParam(':username', $username);
	$q2->execute();

	$info = $q2->fetch();
	?>
<tr>
          <td><?php echo $info['first_name']; ?></td>
          <td><?php echo $info['last_name']; ?></td>
          <td><?php echo $info['state']; ?></td>
          <td><?php echo $info['city']; ?></td>
          <td>
          	<?php
if (isset($_SESSION['username'])) {
	echo "{$info['phone']}";
}else{
	?>
<a href="login.php" class="btn btn-info">Login to see contact</a>
	<?php
}
          	?>
          </td>
          <td><?php
if (isset($_SESSION['username'])) {
	echo "{$info['email']}";
}else{
	?>
<a href="login.php" class="btn btn-info">Login to see contact</a>
	<?php
}
          	?></td>
        </tr>
	<?php
}
      ?>
        
      </tbody>
    </table>
	<?php
}else{
	?>
<div class="alert alert-danger">
No available donor in database.
</div>
	<?php
}
}


?>

</div>
</div>


</div>
</div>
</div>
 


<?php include 'include/footer.php'; ?>

