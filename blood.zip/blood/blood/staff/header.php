<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from templatecycle.com/demo/bootclassified/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Aug 2015 23:13:22 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link rel="shortcut icon" href="../assets/ico/favicon.png">
<title>ONLINE BLOOD BANK</title>
 
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
<link href="../assets/css/style.css" rel="stylesheet">
 
<link href="../assets/css/owl.carousel.css" rel="stylesheet">
<link href="../assets/css/owl.theme.css" rel="stylesheet">
 
 
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
 
<script>
    paceOptions = {
      elements: true
    };
</script>
<script src="../assets/js/pace.min.js"></script>
</head>
<body>

<div id="wrapper">
<div class="header">
<nav class="navbar   navbar-site navbar-default" role="navigation">
<div class="container">
<div class="navbar-header">
<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
<a href="index.php" class="navbar-brand logo logo-title">
 
<img src="../images/logo.png" height="60" /></a> </div>

<div class="navbar-collapse collapse">
<ul class="nav navbar-nav navbar-left" style="margin-top: 20px;">
<li><a href="index.php" style="<?php
if ($path == 'index') {
  echo 'color: #E74C3C;';
}
?>">View donor</a></li>
<li><a href="add.php" style="<?php
if ($path == 'add') {
  echo 'color: #E74C3C;';
}
?>">Add donor</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<li><a href="javascript:;">Welcome <?php echo $_SESSION['staff']; ?>!</a></li>
<li><a href="logout.php" class="btn btn-primary" style="color: #fff; background-color: #E74C3C;
  border-color: #E74C3C;">logout</a></li>
</ul>
</div>

 
</div>
 
</nav>
</div>

