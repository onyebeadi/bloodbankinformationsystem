<?php 
include '../include/connect.php'; 


?>
<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from templatecycle.com/demo/bootclassified/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Aug 2015 23:13:22 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 
<link rel="shortcut icon" href="../assets/ico/favicon.png">
<title>STAFF LOGIN</title>
 
<link href="../assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
<link href="../assets/css/style.css" rel="stylesheet">
 
<link href="../assets/css/owl.carousel.css" rel="stylesheet">
<link href="../assets/css/owl.theme.css" rel="stylesheet">
 
 
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
 
<script>
    paceOptions = {
      elements: true
    };
</script>
<script src="../assets/js/pace.min.js"></script>
</head>
<body>

<div id="wrapper">
<div class="header">
<nav class="navbar   navbar-site navbar-default" role="navigation">
<div class="container">
<div class="navbar-header">
<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
<a href="index.php" class="navbar-brand logo logo-title">
 
<img src="../images/logo.png" height="60" /></a> </div>


 
</div>
 
</nav>
</div>



<div class="main-container">
<div class="container">
<div class="row">
<div class="col-sm-5 login-box">
<div class="panel panel-default">
<div class="panel-intro text-center">
<h2 class="logo-title">
 Staff Login</h2>
</div>
<div class="panel-body">
<?php

if (isset($_POST['username'])) {
	$username = secureText($_POST['username']);
	$password = securePassword($_POST['password']);

	$q = $query->prepare("SELECT * FROM staff WHERE username = :username");
	$q->bindParam(':username', $username);
	$q->execute();

	if ($q->rowCount() != 0) {
		$_SESSION['staff'] = $username;
		header("location: index.php");
	}else{
		?>
<div class="alert alert-danger">
Invalid login details.
</div>
		<?php
	}
}
?>
<form role="form" action="<?php echo htmlspecialchars('login.php'); ?>" method="post">
<div class="form-group">
<label for="sender-email" class="control-label">Username:</label>
<div class="input-icon"> <i class="icon-user fa"></i>
<input id="sender-email" autofocus type="text" name="username" placeholder="Username" class="form-control email">
</div>
</div>
<div class="form-group">
<label for="user-pass" class="control-label">Password:</label>
<div class="input-icon"> <i class="icon-lock fa"></i>
<input type="password" class="form-control" name="password" placeholder="Password" id="user-pass">
</div>
</div>
<div class="form-group">
<button type="submit" class="btn btn-primary  btn-block">Submit</button>
</div>
</form>
</div>
</div>
<div class="login-box-btm text-center" style="margin-bottom: 110px;">
</div>
</div>
</div>
</div>
</div>
 
<div class="footer" id="footer">
<div class="container">
<ul class=" pull-left navbar-link footer-nav">
<li>ONLINE BLOOD BANK PROJECT BY<a href="javascript:;">OLULU STAINLESS CE-10-13</a>
</ul>
<ul class=" pull-right navbar-link footer-nav">
<li> &copy; <?php echo date('Y'); ?> Computer Engineering Department </li>
</ul>
</div>
</div>
 
</div>
 
 
 
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/bootstrap/js/bootstrap.min.js"></script>
 
<script src="../assets/js/owl.carousel.min.js"></script>
 
<script src="../assets/js/jquery.matchHeight-min.js"></script>
 
<script src="../assets/js/hideMaxListItem.js"></script>
 
<script src="../assets/plugins/jquery.fs.scroller/jquery.fs.scroller.js"></script>
<script src="../assets/plugins/jquery.fs.selecter/jquery.fs.selecter.js"></script>
 
<script src="../assets/js/script.js"></script>
 
<script type="text/javascript" src="../assets/plugins/autocomplete/jquery.mockjax.js"></script>
<script type="text/javascript" src="../assets/plugins/autocomplete/jquery.autocomplete.js"></script>
<script type="text/javascript" src="../assets/plugins/autocomplete/usastates.js"></script>
<script type="text/javascript" src="../assets/plugins/autocomplete/autocomplete-demo.js"></script>
</body>

</html>
