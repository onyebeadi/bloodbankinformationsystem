<?php
include('include/connect.php');

unset($_SESSION['staff']);
header("location: login.php");