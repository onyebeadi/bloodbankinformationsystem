<?php
include('../include/connect.php');

if (!isset($_SESSION['staff'])) {
    header('location: login.php');
}

include('header.php');

?>

<div class="container">

      <!-- Main component for a primary marketing message or call to action -->
      <div class="jumbotron" style="min-height: 480px;">
        <h2 style="margin-top: 0px; font-size: 30px;">Existing Donors</h2>

        <?php

if (isset($_POST['ok'])) {
	$username = secureText($_POST['username']);

	$update = $query->prepare("UPDATE donors SET status = 0 WHERE username = :username");
		$update->bindParam('username', $username);

		if ($update->execute()) {
			?>
<div class="alert alert-success">
<strong>Blood donor directory updated successfully</strong>
</div>
			<?php
		}else{
?>
<div class="alert alert-danger">
<strong>Unable to update blood donor directory.</strong>
</div>
<?php
		}


}

if (isset($_POST['remove'])) {
	$username = secureText($_POST['username']);

	$update = $query->prepare("UPDATE donors SET status = 1 WHERE username = :username");
		$update->bindParam('username', $username);

		if ($update->execute()) {
			?>
<div class="alert alert-success">
<strong>Blood donor directory updated successfully</strong>
</div>
			<?php
		}else{
?>
<div class="alert alert-danger">
<strong>Unable to update blood donor directory.</strong>
</div>
<?php
		}
}

$q = $query->prepare("SELECT * FROM donors ORDER BY id DESC");
$q->execute();

if ($q->rowCount() != 0) {
	?>
<table class="table">
      <thead>
        <tr>
          <th>First Name</th>
          <th>Last Name</th>
          <th>Blood Group</th>
          <th>State</th>
          <th>City</th>
          <th>Phone Number</th>
          <th>Email Address</th>
          <th>Availability</th>
        </tr>
      </thead>
      <tbody>
      <?php
while ($row = $q->fetch()) {
	$username = $row['username'];
	$q2 = $query->prepare("SELECT * FROM account WHERE username = :username");
	$q2->bindParam(':username', $username);
	$q2->execute();

	$info = $q2->fetch();
	?>
<tr>
          <td><?php echo $info['first_name']; ?></td>
          <td><?php echo $info['last_name']; ?></td>
          <td><?php echo $info['blood']; ?></td>
          <td><?php echo $info['state']; ?></td>
          <td><?php echo $info['city']; ?></td>
          <td>
          	<?php echo "{$info['phone']}"; ?>
          </td>
          <td><?php echo "{$info['email']}"; ?></td>
          <td>
          <form class="form-horizontal" role="form" action="<?php echo htmlspecialchars('index.php'); ?>" method="post">
<?php
if ($row['status'] == 0) {
	?>
<span style='color: green'>Available</span> <button type="submit" name="remove"  class="btn btn-primary" style="padding: 3px 6px;" title="Do not make available"><span class="glyphicon glyphicon-remove"></span></button>
<input type="hidden" name="username" value="<?php echo $row['username']; ?>" />
	<?php
}else{
	?>
	<span style='color: red'>Not available</span> <button type="submit" name="ok"  class="btn btn-success" style="padding: 3px 6px;" title="Make available"><span class="glyphicon glyphicon-ok"></span></button>
<input type="hidden" name="username" value="<?php echo $row['username']; ?>" />
	<?php
}
?>
</form>
          </td>
        </tr>
	<?php
}
      ?>
        
      </tbody>
    </table>
	<?php
}else{
	?>
<div class="alert alert-danger">
<strong>No availble donor in the database</strong>
</div>
	<?php
}
        ?>
        
          <a class="btn btn-lg btn-primary" href="add.php" role="button">Add donor »</a>
        </p>
      </div>

    </div> <!-- /container -->

<?php
include('footer.php');
?>