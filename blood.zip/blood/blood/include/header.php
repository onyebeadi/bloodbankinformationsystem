<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from templatecycle.com/demo/bootclassified/ by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 08 Aug 2015 23:13:22 GMT -->
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
 
<link rel="apple-touch-icon-precomposed" sizes="144x144" href="assets/ico/apple-touch-icon-144-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="114x114" href="assets/ico/apple-touch-icon-114-precomposed.png">
<link rel="apple-touch-icon-precomposed" sizes="72x72" href="assets/ico/apple-touch-icon-72-precomposed.png">
<link rel="apple-touch-icon-precomposed" href="ico/apple-touch-icon-57-precomposed.html">
<link rel="shortcut icon" href="assets/ico/favicon.png">
<title>ONLINE BLOOD BANK</title>
 
<link href="assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 
<link href="assets/css/style.css" rel="stylesheet">
 
<link href="assets/css/owl.carousel.css" rel="stylesheet">
<link href="assets/css/owl.theme.css" rel="stylesheet">
 
 
<!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->
 
<script>
    paceOptions = {
      elements: true
    };
</script>
<script src="assets/js/pace.min.js"></script>
</head>
<body>

<div id="wrapper">
<div class="header">
<nav class="navbar   navbar-site navbar-default" role="navigation">
<div class="container">
<div class="navbar-header">
<button data-target=".navbar-collapse" data-toggle="collapse" class="navbar-toggle" type="button"> <span class="sr-only">Toggle navigation</span> <span class="icon-bar"></span> <span class="icon-bar"></span> <span class="icon-bar"></span> </button>
<a href="index.php" class="navbar-brand logo logo-title">
 
<img src="images/logo.png" height="60" /></a> </div>
<?php
if (isset($_SESSION['username'])) {
	?>
<div class="navbar-collapse collapse">
<ul class="nav navbar-nav navbar-left" style="margin-top: 20px;">
<li><a href="index.php">Find a Donor</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<li><a href="profile.php"> <span>
<?php
$username = $_SESSION['username'];

$q = $query->prepare("SELECT * FROM account WHERE username = :username");
$q->bindParam(':username', $username);
$q->execute();

$row = $q->fetch();
$name = $row['last_name']." ".$row['first_name'];
echo $name;
?>
</span> <i class="icon-user fa"></i> </a>
</li>
<li><a href="logout.php">Logout <i class="glyphicon glyphicon-off"></i> </a></li>
<?php
$username = $_SESSION['username'];

$qs = $query->prepare("SELECT * FROM donors WHERE username = :username AND status = 0");
$qs->bindParam(':username', $username);
$qs->execute();

if ($qs->rowCount() != 0) {
	?>
<li class="postadd"><button class="btn btn-block btn-border btn-post btn-danger" data-target="#cancelModal" data-toggle="modal">Cancel Donation</button></li>
	<?php
}else{
?>
<li class="postadd"><button class="btn btn-block btn-border btn-post btn-danger" data-target="#donateModal" data-toggle="modal">Donate Blood</button></li>
<?php
}
?>

</ul>
</div>
	<?php
}else{
	?>
<div class="navbar-collapse collapse">
<ul class="nav navbar-nav navbar-left" style="margin-top: 20px;">
<li><a href="index.php">Find a Donor</a></li>
</ul>
<ul class="nav navbar-nav navbar-right">
<li><a href="login.php">Login</a></li>
<li><a href="register.php">Register</a></li>
</ul>
</div>
	<?php
}
?>

 
</div>
 
</nav>
</div>

<!-- Donate Modal -->
    <div class="modal fade bs-example-modal-sm" id="donateModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">

        <div class="modal-header" style="padding: 5px;">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title" id="mySmallModalLabel">Donate Blood</h4>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to donate blood?</p>
<p style="color: red"><strong>Your name and contact info will be added to the blood bank donor directory.</strong></p>
          <center>
          <form action="<?php echo htmlspecialchars('index.php'); ?>" method="post">
<button type="submit" name="donate" class="btn btn-success">Yes</button> <button class="btn btn-danger" data-dismiss="modal">No</button>
</form>
          </center>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div>

  <!-- Cancel Donate Modal -->
    <div class="modal fade bs-example-modal-sm" id="cancelModal" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true" style="display: none;">
    <div class="modal-dialog modal-sm">
      <div class="modal-content">

        <div class="modal-header" style="padding: 5px;">
          <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
          <h4 class="modal-title" id="mySmallModalLabel">Cancelling Blood Donation</h4>
        </div>
        <div class="modal-body">
          <p>Are you sure you want to cancel your blood donation?</p>
          <p style="color: red"><strong>Your name and contact info will be removed from the blood bank donor directory.</strong></p>
          <center>
          <form action="<?php echo htmlspecialchars('index.php'); ?>" method="post">
<button type="submit" name="cancel" class="btn btn-success">Yes</button> <button class="btn btn-danger" data-dismiss="modal">No</button>
</form>
          </center>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
  </div>