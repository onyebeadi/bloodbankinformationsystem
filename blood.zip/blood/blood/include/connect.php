<?php
session_start();
// Access information
$host = 'localhost';
$user = 'root';
$pwd = '';

$db = 'bloodbank';

//connect to server
$query = new PDO("mysql:dbname=$db;host=$host", $user, $pwd);

function secureText($txt) {
	$txt = htmlentities($txt);
	$txt = stripslashes($txt);
	return $txt;
}

function securePassword($pwd) {
	$pwd = sha1($pwd);
	$pwd = htmlentities($pwd);
	$pwd = stripslashes($pwd);
	return $pwd;
}

//getting current date and time
	$d = date("d-m-Y");
	$t = date("h:i:sa");
	$date = $d.' | '.$t;
	$now =  time();


$path = basename($_SERVER['PHP_SELF'], '.php');
