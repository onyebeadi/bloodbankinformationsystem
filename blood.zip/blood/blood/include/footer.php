<div class="footer" id="footer">
<div class="container">
<ul class=" pull-left navbar-link footer-nav">
<li>ONLINE BLOOD BANK PROJECT BY<a href="javascript:;">OLULU STAINLESS CE-10-13</a>
</ul>
<ul class=" pull-right navbar-link footer-nav">
<li> &copy; <?php echo date('Y'); ?> Computer Engineering Department </li>
</ul>
</div>
</div>
 
</div>
 
 
 
<script src="assets/js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
 
<script src="assets/js/owl.carousel.min.js"></script>
 
<script src="assets/js/jquery.matchHeight-min.js"></script>
 
<script src="assets/js/hideMaxListItem.js"></script>
 
<script src="assets/plugins/jquery.fs.scroller/jquery.fs.scroller.js"></script>
<script src="assets/plugins/jquery.fs.selecter/jquery.fs.selecter.js"></script>
 
<script src="assets/js/script.js"></script>
 
<script type="text/javascript" src="assets/plugins/autocomplete/jquery.mockjax.js"></script>
<script type="text/javascript" src="assets/plugins/autocomplete/jquery.autocomplete.js"></script>
<script type="text/javascript" src="assets/plugins/autocomplete/usastates.js"></script>
<script type="text/javascript" src="assets/plugins/autocomplete/autocomplete-demo.js"></script>
</body>

</html>
