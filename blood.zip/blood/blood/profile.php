<?php 
include 'include/connect.php'; 

include 'include/header.php'; 
?>

<div class="main-container">
<div class="container">
<div class="row">

<div class="inner-box category-content">
<h2 class="title-2"> <i class="icon-user-add"></i> Edit your Account <button class="btn btn-danger" data-target="#passwordModal" data-toggle="modal">Change Password</button></h2>
<div class="row">
<div class="col-sm-12">
<?php
if (isset($_POST['first_name'])) {
	$username = secureText($_SESSION['username']);

	$first_name = secureText($_POST['first_name']);
	$last_name = secureText($_POST['last_name']);
	$email = secureText($_POST['email']);
	$dob = secureText($_POST['dob']);
	$gender = secureText($_POST['gender']);
	$blood = secureText($_POST['blood']);
	$address = secureText($_POST['address']);
	$state = secureText($_POST['state']);
	$city = secureText($_POST['city']);
	$phone = secureText($_POST['phone']);

	
	$update = $query->prepare("UPDATE donors SET state = :state, blood = :blood WHERE username = :username");
		$update->bindParam('username', $username);
		$update->bindParam(':state', $state);
		$update->bindParam(':blood', $blood);

		$q = $query->prepare("UPDATE account SET first_name = :first_name, last_name = :last_name, email = :email, dob = :dob, gender = :gender, blood = :blood, address = :address, state = :state, city = :city, phone = :phone WHERE username = :username");
		$q->bindParam(':username', $username);
		$q->bindParam(':first_name', $first_name);
		$q->bindParam(':last_name', $last_name);
		$q->bindParam(':email', $email);
		$q->bindParam(':dob', $dob);
		$q->bindParam(':gender', $gender);
		$q->bindParam(':blood', $blood);
		$q->bindParam(':address', $address);
		$q->bindParam(':state', $state);
		$q->bindParam(':city', $city);
		$q->bindParam(':phone', $phone);

		if ($q->execute() && $update->execute()) {
			# registration successful...
			?>
<div class="alert alert-success">
<strong>Your account was successfully updated.</strong><br>
Reloading page...
</div>
<script>
setTimeout(function() {
window.location.replace('profile.php');
}, 2000);
</script>
			<?php
		}else {
?>
<div class="alert alert-danger">
<strong>Your account was not successful.</strong>
</div>
			<?php
		}

	
}

///password reset

if (isset($_POST['old_pwd'])) {

  $old = securePassword($_POST['old_pwd']);
  $new = securePassword($_POST['new_pwd']);
  $new2 = securePassword($_POST['repeat_pwd']);
  $username = secureText($_SESSION['username']);
	

  if ($new != $new2) {
    ?>
<div class="alert alert-danger">
Incorrect repeated password.
</div>
    <?php
  }else{
    $q = $query->prepare("SELECT * FROM account WHERE username = :username AND password = :pwd");
    $q->bindParam(':pwd', $old);
    $q->bindParam(':username', $username);
    $q->execute();

    if ($q->rowCount() != 0) {
      $q2 = $query->prepare("UPDATE account SET password = :pwd WHERE username = :username AND password = :pwd2");
      $q2->bindParam(':pwd', $new);
      $q2->bindParam(':username', $username);
    $q2->bindParam(':pwd2', $old);

      if ($q2->execute()) {
        ?>
<div class="alert alert-success">
Password successfully updated.
</div>
        <?php
      }else{
?>
<div class="alert alert-danger">
Unable to update password.
</div>
        <?php
      }
//changing password

    }else{
?>
<div class="alert alert-danger">
Incorrect old password.
</div>
<?php
    }

  }

  
}


	$username = secureText($_SESSION['username']);

	$q = $query->prepare("SELECT * FROM account WHERE username = :username");
	$q->bindParam(':username', $username);
	$q->execute();

	$row = $q->fetch();

?>
<form class="form-horizontal" action="<?php echo htmlspecialchars('profile.php'); ?>" method="post">
<fieldset>
<div class="form-group required">
<label class="col-md-4 control-label">First Name <sup>*</sup></label>
<div class="col-md-6">
<input name="first_name" autofocussecurePassword placeholder="First Name" value="<?php echo $row['first_name']; ?>" class="form-control input-md" required type="text">
</div>
</div>
 
<div class="form-group required">
<label class="col-md-4 control-label">Last Name <sup>*</sup></label>
<div class="col-md-6">
<input name="last_name" placeholder="Last Name" value="<?php echo $row['last_name']; ?>" required class="form-control input-md" type="text">
</div>
</div>
 
<div class="form-group required">
<label for="inputEmail3" class="col-md-4 control-label">Email Address <sup>*</sup></label>
<div class="col-md-6">
<input type="email" class="form-control" id="inputEmail3" value="<?php echo $row['email']; ?>" name="email" required placeholder="Email">
</div>
</div>

<div class="form-group required">
<label class="col-md-4 control-label">Phone Number <sup>*</sup></label>
<div class="col-md-6">
<input name="phone" placeholder="Phone Number" value="<?php echo $row['phone']; ?>" required class="form-control input-md" type="text">
</div>
</div>

<div class="form-group required">
<label class="col-md-4 control-label">Date of Birth <sup>*</sup></label>
<div class="col-md-6">
<input name="dob" placeholder="Last Name" value="<?php echo $row['dob']; ?>" required class="form-control input-md" type="date">
</div>
</div>
 
<div class="form-group">
<label class="col-md-4 control-label">Gender <sup>*</sup></label>
<div class="col-md-6">
<div class="radio">
<label for="Gender-0">
<input name="gender" id="Gender-0" value="male" checked="checked" type="radio">
Male </label>
</div>
<div class="radio">
<label for="Gender-1">
<input name="gender" id="Gender-1" value="female" type="radio">
Female </label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-4 control-label">Blood Group <sup>*</sup></label>
<div class="col-md-6">
<select class="form-control" name="blood">
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-md-4 control-label">State <sup>*</sup></label>
<div class="col-md-6">
<select class="form-control" name="state">
<option value="Abia">Abia</option>
<option value="Adamawa">Adamawa</option>
<option value="Abuja">Abuja</option>
<option value="Akwa ibom">Akwa ibom</option>
<option value="Anambra">Anambra</option>
<option value="Bauchi">Bauchi</option>
<option value="Bayelsa">Bayelsa</option>
<option value="Benue">Benue</option>
<option value="Borno">Borno</option>
<option value="Cross river">Cross river</option>
<option value="Delta">Delta</option>
<option value="Ebonyi">Ebonyi</option>
<option value="Edo">Edo</option>
<option value="Ekiti">Ekiti</option>
<option value="Enugu">Enugu</option>
<option value="Gombe">Gombe</option>
<option value="Imo">Imo</option>
<option value="Jigawa">Jigawa</option>
<option value="Kaduna">Kaduna</option>
<option value="Kano">Kano</option>
<option value="Katsina">Katsina</option>
<option value="Kebbi">Kebbi</option>
<option value="Kogi">Kogi</option>
<option value="Kwara">Kwara</option>
<option value="Nassarawa">Nassarawa</option>
<option value="Niger">Niger</option>
<option value="Lagos">Lagos</option>
<option value="Ogun">Ogun</option>
<option value="Ondo">Ondo</option>
<option value="Osun">Osun</option>
<option value="Oyo">Oyo</option>
<option value="Plateau">Plateau</option>
<option value="Rivers">Rivers</option>
<option value="Sokoto">Sokoto</option>
<option value="Taraba">Taraba</option>
<option value="Yobe">Yobe</option>
<option value="Zamfara">Zamfara</option>
</select>
</div>
</div>

<div class="form-group required">
<label class="col-md-4 control-label">City <sup>*</sup></label>
<div class="col-md-6">
<input name="city" placeholder="City" value="<?php echo $row['city']; ?>" required class="form-control input-md" type="text">
</div>
</div>
 
<div class="form-group">
<label class="col-md-4 control-label" for="textarea">Address <sup>*</sup></label>
<div class="col-md-6">
<textarea class="form-control" id="textarea" required name="address" placeholder="Address"><?php echo $row['address']; ?></textarea>
</div>
</div>

<div class="form-group">
<label class="col-md-4 control-label"></label>
<div class="col-md-8">
<div style="clear:both"></div>
<button type="submit" class="btn btn-primary">Save Changes</button> </div>
</div>
</fieldset>
</form>
</div>
</div>
</div>
 
</div>
 
</div>
 
</div>

<!-- Modal -->
<div class="modal fade" id="passwordModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form class="form-horizontal" action="<?php echo htmlspecialchars('profile.php'); ?>" method="post">
<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
        <h4 class="modal-title" id="myModalLabel">Change Password</h4>
      </div>
      <div class="modal-body" style="padding: 10px 30px;">
        <div class="form-group">
<label>Old Password</label>
<input type="password" class="form-control" required name="old_pwd" placeholder="Old Password" />
</div>
<div class="form-group">
<label>New Password</label>
<input type="password" class="form-control" name="new_pwd" required placeholder="New Password" />
</div>
<div class="form-group">
<label>Repeat Password</label>
<input type="password" class="form-control" name="repeat_pwd" required placeholder="Repeat Password" />
</div>
      </div>
      <div class="modal-footer">
        <button type="submit" class="btn btn-primary">Save changes</button>
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
      </form>
    </div>
  </div>
</div>

<?php include 'include/footer.php'; ?>