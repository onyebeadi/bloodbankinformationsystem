<?php
include('include/connect.php');

unset($_SESSION['username']);
header("location: index.php");