<?php 
include 'include/connect.php'; 

include 'include/header.php'; 
?>

<div class="main-container">
<div class="container">
<div class="row">

<div class="inner-box category-content">
<h2 class="title-2"> <i class="icon-user-add"></i> Create your account, Its free </h2>
<div class="row">
<div class="col-sm-12">
<?php
if (isset($_POST['username'])) {
	$username = secureText($_POST['username']);
	$password = securePassword($_POST['password']);
	$first_name = secureText($_POST['first_name']);
	$last_name = secureText($_POST['last_name']);
	$email = secureText($_POST['email']);
	$dob = secureText($_POST['dob']);
	$gender = secureText($_POST['gender']);
	$blood = secureText($_POST['blood']);
	$address = secureText($_POST['address']);
	$state = secureText($_POST['state']);
	$city = secureText($_POST['city']);
	$phone = secureText($_POST['phone']);

	$q = $query->prepare("SELECT * FROM account WHERE username = :username");
	$q->bindParam(':username', $username);
	$q->execute();

	if ($q->rowCount() != 0) {
		# Username exist in database
		?>
<div class="alert alert-danger">
Username already exist.
</div>
		<?php
	}else{
		$q = $query->prepare("INSERT INTO account (username, password, first_name, last_name, email, dob, gender, blood, address, state, city, phone) VALUES (:username, :password, :first_name, :last_name, :email, :dob, :gender, :blood, :address, :state, :city, :phone)");
		$q->bindParam(':username', $username);
		$q->bindParam(':password', $password);
		$q->bindParam(':first_name', $first_name);
		$q->bindParam(':last_name', $last_name);
		$q->bindParam(':email', $email);
		$q->bindParam(':dob', $dob);
		$q->bindParam(':gender', $gender);
		$q->bindParam(':blood', $blood);
		$q->bindParam(':address', $address);
		$q->bindParam(':state', $state);
		$q->bindParam(':city', $city);
		$q->bindParam(':phone', $phone);

		if ($q->execute()) {
			# registration successful...
			?>
<div class="alert alert-success">
<strong>Thank you for registering.</strong><br>
your registration was successful.
</div>
			<?php
		}else {
?>
<div class="alert alert-danger">
<strong>Not successful.</strong><br>
your registration was not successful.
</div>
			<?php
		}

	}
}
?>
<form class="form-horizontal" action="<?php echo htmlspecialchars('register.php'); ?>" method="post">
<fieldset>
 <div class="form-group required">
<label for="inputEmail3" class="col-md-4 control-label">Username <sup>*</sup></label>
<div class="col-md-6">
<input type="text" name="username" class="form-control" autofocus id="inputEmail3" required placeholder="Username">
</div>
</div>
<div class="form-group required">
<label for="inputPassword3" class="col-md-4 control-label">Password <sup>*</sup></label>
<div class="col-md-6">
<input type="password" name="password" class="form-control" id="inputPassword3" required placeholder="Password">
</div>
</div>
<hr>
<div class="form-group required">
<label class="col-md-4 control-label">First Name <sup>*</sup></label>
<div class="col-md-6">
<input name="first_name" placeholder="First Name" class="form-control input-md" required type="text">
</div>
</div>
 
<div class="form-group required">
<label class="col-md-4 control-label">Last Name <sup>*</sup></label>
<div class="col-md-6">
<input name="last_name" placeholder="Last Name" required class="form-control input-md" type="text">
</div>
</div>
 
<div class="form-group required">
<label for="inputEmail3" class="col-md-4 control-label">Email Address <sup>*</sup></label>
<div class="col-md-6">
<input type="email" class="form-control" id="inputEmail3" name="email" required placeholder="Email">
</div>
</div>

<div class="form-group required">
<label class="col-md-4 control-label">Phone Number <sup>*</sup></label>
<div class="col-md-6">
<input name="phone" placeholder="Phone Number" required class="form-control input-md" type="text">
</div>
</div>

<div class="form-group required">
<label class="col-md-4 control-label">Date of Birth <sup>*</sup></label>
<div class="col-md-6">
<input name="dob" placeholder="Last Name" required class="form-control input-md" type="date">
</div>
</div>
 
<div class="form-group">
<label class="col-md-4 control-label">Gender <sup>*</sup></label>
<div class="col-md-6">
<div class="radio">
<label for="Gender-0">
<input name="gender" id="Gender-0" value="male" checked="checked" type="radio">
Male </label>
</div>
<div class="radio">
<label for="Gender-1">
<input name="gender" id="Gender-1" value="female" type="radio">
Female </label>
</div>
</div>
</div>

<div class="form-group">
<label class="col-md-4 control-label">Blood Group <sup>*</sup></label>
<div class="col-md-6">
<select class="form-control" name="blood">
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-md-4 control-label">State <sup>*</sup></label>
<div class="col-md-6">
<select class="form-control" name="state">
<option value="Abia">Abia</option>
<option value="Adamawa">Adamawa</option>
<option value="Abuja">Abuja</option>
<option value="Akwa ibom">Akwa ibom</option>
<option value="Anambra">Anambra</option>
<option value="Bauchi">Bauchi</option>
<option value="Bayelsa">Bayelsa</option>
<option value="Benue">Benue</option>
<option value="Borno">Borno</option>
<option value="Cross river">Cross river</option>
<option value="Delta">Delta</option>
<option value="Ebonyi">Ebonyi</option>
<option value="Edo">Edo</option>
<option value="Ekiti">Ekiti</option>
<option value="Enugu">Enugu</option>
<option value="Gombe">Gombe</option>
<option value="Imo">Imo</option>
<option value="Jigawa">Jigawa</option>
<option value="Kaduna">Kaduna</option>
<option value="Kano">Kano</option>
<option value="Katsina">Katsina</option>
<option value="Kebbi">Kebbi</option>
<option value="Kogi">Kogi</option>
<option value="Kwara">Kwara</option>
<option value="Nassarawa">Nassarawa</option>
<option value="Niger">Niger</option>
<option value="Lagos">Lagos</option>
<option value="Ogun">Ogun</option>
<option value="Ondo">Ondo</option>
<option value="Osun">Osun</option>
<option value="Oyo">Oyo</option>
<option value="Plateau">Plateau</option>
<option value="Rivers">Rivers</option>
<option value="Sokoto">Sokoto</option>
<option value="Taraba">Taraba</option>
<option value="Yobe">Yobe</option>
<option value="Zamfara">Zamfara</option>
</select>
</div>
</div>

<div class="form-group required">
<label class="col-md-4 control-label">City <sup>*</sup></label>
<div class="col-md-6">
<input name="city" placeholder="City" required class="form-control input-md" type="text">
</div>
</div>
 
<div class="form-group">
<label class="col-md-4 control-label" for="textarea">Address <sup>*</sup></label>
<div class="col-md-6">
<textarea class="form-control" id="textarea" required name="address" placeholder="Address"></textarea>
</div>
</div>

<div class="form-group">
<label class="col-md-4 control-label"></label>
<div class="col-md-8">
<div class="termbox mb10">
<label class="checkbox-inline" for="checkboxes-1">
<input name="tac" id="checkboxes-1" value="1" required type="checkbox">
I have read and agree to the <a href="javascript:;">Terms & Conditions</a> </label>
</div>
<div style="clear:both"></div>
<button type="submit" class="btn btn-primary">Register</button> </div>
</div>
</fieldset>
</form>
</div>
</div>
</div>
 
</div>
 
</div>
 
</div>

<?php include 'include/footer.php'; ?>