Create a new database call it bloodbank. 
Enter the new database and import the file 
bloodbank.sql into the database.

After creating and importing the database;
You can now login as admin using --

username = admin
password = ubuntu

enter /staff to get access to the staff page